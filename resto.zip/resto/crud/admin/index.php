<?php
session_start();

// Cek apakah pengguna sudah logout
if (!isset($_SESSION['user'])) {
  header("Location: login_admin.php");
  exit();
}


// Ambil nama dan role dari session
$fullName = $_SESSION['user']['full_name'] ?? 'User';
$role     = $_SESSION['user']['role'] ?? 'Role';

// Nonaktifkan cache halaman ini
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// Ambil koneksi database
$db = include 'koneksi.php';

// Hitung jumlah table reservation dengan status pending
$stmt = $db->prepare("SELECT COUNT(*) FROM table_reservations WHERE status = 'pending'");
$stmt->execute();
$pendingTableResv = $stmt->fetchColumn();

// Set timezone ke Jakarta
date_default_timezone_set('Asia/Jakarta');

// Ambil tanggal hari ini (format: YYYY-MM-DD)
$today = date('Y-m-d');

// Ambil total reservasi meja yang tanggal reservasinya hari ini
$stmtTodayResv = $db->prepare("SELECT COUNT(*) FROM table_reservations WHERE DATE(reservation_datetime) = :today");
$stmtTodayResv->bindValue(':today', $today, PDO::PARAM_STR);
$stmtTodayResv->execute();
$totalTodayTableResv = $stmtTodayResv->fetchColumn();


// Ambil total Dine-In dengan midtrans_order_id yang dibuat hari ini
$stmtDineinToday = $db->prepare("SELECT COUNT(*) FROM orders 
    WHERE order_type = 'dine-in' 
    AND midtrans_order_id IS NOT NULL 
    AND midtrans_order_id != ''
    AND DATE(created_at) = :today");

$stmtDineinToday->bindValue(':today', $today, PDO::PARAM_STR);
$stmtDineinToday->execute();
$totalDineinToday = $stmtDineinToday->fetchColumn();

// Query total delivery order hari ini yang ada midtrans_order_id
$stmtDeliveryToday = $db->prepare("SELECT COUNT(*) FROM delivery_orders 
    WHERE midtrans_order_id IS NOT NULL 
    AND midtrans_order_id != ''
    AND order_date = :today");

$stmtDeliveryToday->bindValue(':today', $today, PDO::PARAM_STR);
$stmtDeliveryToday->execute();
$totalDeliveryToday = $stmtDeliveryToday->fetchColumn();

// Query total bahan dengan status low stock
$stmtLowStock = $db->prepare("SELECT COUNT(*) FROM stock WHERE status = 'low stock'");
$stmtLowStock->execute();
$totalLowStock = $stmtLowStock->fetchColumn();

// Total bahan yang Out of Stock
$stmtOutStock = $db->prepare("SELECT COUNT(*) FROM stock WHERE status = 'Out of Stock'");
$stmtOutStock->execute();
$totalOutStock = $stmtOutStock->fetchColumn();

date_default_timezone_set('Asia/Jakarta');

// Helper untuk dapatkan awal minggu, bulan, dan tahun
$today = date('Y-m-d');
$startOfWeek = date('Y-m-d', strtotime('monday this week'));
$startOfMonth = date('Y-m-01');
$startOfYear = date('Y-01-01');

// SALES dari orders + delivery_orders yang ada midtrans_order_id
function getSalesData($db, $interval) {
    switch ($interval) {
        case 'week':
            $labels = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
            $data = array_fill(0, 7, 0);
            $query = "
                SELECT DATE(created_at) as date, COUNT(*) as total 
                FROM orders 
                WHERE midtrans_order_id IS NOT NULL 
                AND created_at >= :start 
                GROUP BY DATE(created_at)
                UNION ALL
                SELECT order_date as date, COUNT(*) as total 
                FROM delivery_orders 
                WHERE midtrans_order_id IS NOT NULL 
                AND order_date >= :start 
                GROUP BY order_date
            ";
            $stmt = $db->prepare($query);
            $stmt->execute(['start' => date('Y-m-d', strtotime('monday this week'))]);
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $dayIndex = date('N', strtotime($row['date'])) - 1; // 0 = Monday
                $data[$dayIndex] += (int)$row['total'];
            }
            break;

        case 'month':
            $labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
            $data = array_fill(0, 4, 0);
            $query = "
                SELECT created_at FROM orders 
                WHERE midtrans_order_id IS NOT NULL 
                AND created_at >= :start
                UNION ALL
                SELECT CONCAT(order_date, ' 00:00:00') FROM delivery_orders 
                WHERE midtrans_order_id IS NOT NULL 
                AND order_date >= :start
            ";
            $stmt = $db->prepare($query);
            $stmt->execute(['start' => date('Y-m-01')]);
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $datetime) {
                $day = date('j', strtotime($datetime));
                $weekIndex = floor(($day - 1) / 7);
                if ($weekIndex < 4) $data[$weekIndex]++;
            }
            break;

        case 'year':
            $labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $data = array_fill(0, 12, 0);
            $query = "
                SELECT created_at FROM orders 
                WHERE midtrans_order_id IS NOT NULL 
                AND created_at >= :start
                UNION ALL
                SELECT CONCAT(order_date, ' 00:00:00') FROM delivery_orders 
                WHERE midtrans_order_id IS NOT NULL 
                AND order_date >= :start
            ";
            $stmt = $db->prepare($query);
            $stmt->execute(['start' => date('Y-01-01')]);
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $datetime) {
                $month = (int)date('n', strtotime($datetime));
                $data[$month - 1]++;
            }
            break;
    }

    return ['labels' => $labels, 'data' => $data];
}

// TABLE RESERVATIONS dengan transaction_id IS NOT NULL
function getReservationData($db, $interval) {
    $query = "SELECT reservation_datetime FROM table_reservations WHERE transaction_id IS NOT NULL AND reservation_datetime >= :start";
    $labels = [];
    $data = [];

    switch ($interval) {
        case 'week':
            $labels = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
            $data = array_fill(0, 7, 0);
            $start = date('Y-m-d', strtotime('monday this week'));
            break;
        case 'month':
            $labels = ['Week 1','Week 2','Week 3','Week 4'];
            $data = array_fill(0, 4, 0);
            $start = date('Y-m-01');
            break;
        case 'year':
            $labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $data = array_fill(0, 12, 0);
            $start = date('Y-01-01');
            break;
    }

    $stmt = $db->prepare($query);
    $stmt->execute(['start' => $start]);

    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $dt) {
        $time = strtotime($dt);
        if ($interval == 'week') {
            $day = date('N', $time) - 1;
            $data[$day]++;
        } elseif ($interval == 'month') {
            $day = date('j', $time);
            $weekIndex = floor(($day - 1) / 7);
            if ($weekIndex < 4) $data[$weekIndex]++;
        } elseif ($interval == 'year') {
            $month = (int)date('n', $time);
            $data[$month - 1]++;
        }
    }

    return ['labels' => $labels, 'data' => $data];
}

// Buat JSON untuk JS
$weekly  = [
  'labels' => getSalesData($db, 'week')['labels'],
  'sales' => getSalesData($db, 'week')['data'],
  'booking' => getReservationData($db, 'week')['data']
];
$monthly = [
  'labels' => getSalesData($db, 'month')['labels'],
  'sales' => getSalesData($db, 'month')['data'],
  'booking' => getReservationData($db, 'month')['data']
];
$yearly  = [
  'labels' => getSalesData($db, 'year')['labels'],
  'sales' => getSalesData($db, 'year')['data'],
  'booking' => getReservationData($db, 'year')['data']
];
?>



<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../../dash/assets/"
  data-template="vertical-menu-template-free">

<head>
  <meta charset="utf-8" />
  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title>Ocean's Feast</title>

  <meta name="description" content="" />

  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="../../img/hero.PNG" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet" />

  <!-- Icons. Uncomment required icon fonts -->
  <link rel="stylesheet" href="../../dash/assets/vendor/fonts/boxicons.css" />

  <!-- Core CSS -->
  <link rel="stylesheet" href="../../dash/assets/vendor/css/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="../../dash/assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="../../dash/assets/css/demo.css" />

  <!-- Vendors CSS -->
  <link rel="stylesheet" href="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

  <link rel="stylesheet" href="../../dash/assets/vendor/libs/apex-charts/apex-charts.css" />

  <!-- Page CSS -->

  <!-- Helpers -->
  <script src="../../dash/assets/vendor/js/helpers.js"></script>

  <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
  <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
  <script src="../../dash/assets/js/config.js"></script>
</head>

<body>
  <!-- Layout wrapper -->
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->

      <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
        <div class="app-brand demo">
          <a href="index.html" class="app-brand-link">
            <span class="app-brand-logo demo">
              <img src="../../img/hero.PNG" alt="" style="width: 60px;">
            </span>
            <span class="app-brand-text demo menu-text fw-bolder ms-2">Ocean's Feast</span>
          </a>

          <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
          </a>
        </div>

        <div class="menu-inner-shadow"></div>

        <ul class="menu-inner py-1">
          <!-- Dashboard -->
          <li class="menu-item active">
            <a href="index.php" class="menu-link">
              <i class="menu-icon tf-icons bx bx-home-circle"></i>
              <div data-i18n="Analytics">Dashboard</div>
            </a>
          </li>

          <!-- Layouts -->
          <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
              <i class="menu-icon tf-icons bx bx-layout"></i>
              <div data-i18n="Layouts">Report</div>
            </a>

            <ul class="menu-sub">
              <li class="menu-item">
                <a href="report_dineinsales.php" class="menu-link">
                  <div data-i18n="Without menu">Dine-In Sales</div>
                </a>
              </li>
              <li class="menu-item">
                <a href="report_deliverysales.php" class="menu-link">
                  <div data-i18n="Without menu">Delivery Sales</div>
                </a>
              </li>
              <li class="menu-item">
                <a href="report_tableresv.php" class="menu-link">
                  <div data-i18n="Without menu">Table Reservations</div>
                </a>
              </li>
            </ul>
          </li>

          <li class="menu-header small text-uppercase">
            <span class="menu-header-text">Restaurant Ops</span>
          </li>
          <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
              <i class="menu-icon tf-icons bx bx-dock-top"></i>
              <div data-i18n="Account Settings">Master Data </div>
            </a>
            <ul class="menu-sub">
              <li class="menu-item">
                <a href="menu.php" class="menu-link">
                  <div data-i18n="Account">Menu</div>
                </a>
              </li>
              <!-- <li class="menu-item">
                  <a href="lunchcombos.html" class="menu-link">
                    <div data-i18n="Notifications">Category Menu</div>
                  </a>
                </li> -->
              <!-- <li class="menu-item">
                  <a href="snackssips.html" class="menu-link">
                    <div data-i18n="Connections">Snacks & Sips</div>
                  </a>
                </li> -->
            </ul>
          </li>
          <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-box"></i>
                <div data-i18n="Authentications">Stock Management</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="stock.php" class="menu-link">
                    <div data-i18n="Basic">Stock</div>
                  </a>
                </li>
                <!-- <li class="menu-item">
                  <a href="report_stock" class="menu-link" target="_blank">
                    <div data-i18n="Basic">Report Stock</div>
                  </a>
                </li> -->
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-box"></i>
                <div data-i18n="Authentications">Transaction</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="table_reservations.php" class="menu-link">
                    <div data-i18n="Basic">Table Reservation</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="cashier_dinein.php" class="menu-link">
                    <div data-i18n="Basic">Dine-In</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="cashier_delivery.php" class="menu-link">
                    <div data-i18n="Basic">Delivery Order</div>
                  </a>
                </li>
              </ul>
              
            </li>

          <!-- Auth -->
          <li class="menu-header small text-uppercase"><span class="menu-header-text">Access Control</span></li>
          <!-- Cards -->
          <li class="menu-item">
            <a href="user.php" class="menu-link">
              <i class="menu-icon tf-icons bx bx-collection"></i>
              <div data-i18n="Basic">User</div>
            </a>
          </li>
          <!-- <li class="menu-item">
                <a href="changepass.html" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-lock-open-alt"></i>
                  <div data-i18n="Basic">Change Password</div>
                </a>
              </li> -->
      </aside>
      <!-- / Menu -->

      <!-- Layout container -->
      <div class="layout-page">
        <!-- Navbar -->

        <nav
          class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
          id="layout-navbar">
          <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
            <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
              <i class="bx bx-menu bx-sm"></i>
            </a>
          </div>

          <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
            <ul class="navbar-nav flex-row align-items-center ms-auto">
              <!-- User -->
              <li class="nav-item navbar-dropdown dropdown-user dropdown">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                  <div class="avatar avatar-online">
                    <img src="../../dash/assets/img/avatars/person_ava.jpg" alt class="w-px-40 h-auto rounded-circle" />
                  </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
  <li>
    <a class="dropdown-item" href="#">
      <div class="d-flex">
        <div class="flex-shrink-0 me-3">
          <div class="avatar avatar-online">
            <img src="../../dash/assets/img/avatars/person_ava.jpg" alt="User Avatar" class="w-px-40 h-auto rounded-circle" />
          </div>
        </div>
        <div class="flex-grow-1">
          <span class="fw-semibold d-block"><?= $fullName ?></span>
          <small class="text-muted"><?= $role ?></small>
        </div>
      </div>
    </a>
  </li>
  <li>
    <div class="dropdown-divider"></div>
  </li>
  <li>
    <a class="dropdown-item" href="logout.php">
      <i class="bx bx-power-off me-2"></i>
      <span class="align-middle">Log Out</span>
    </a>
  </li>
</ul>
              </li>
              <!--/ User -->
            </ul>
          </div>
        </nav>

        <!-- / Navbar -->

        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

          <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
              <div class="col-lg-8 mb-4 order-0">
                <div class="card">
                  <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                      <div class="card-body">
                        <h5 class="card-title text-primary">Hello! 🎉</h5>
                        <p class="mb-4">
                          Welcome to the <span class="fw-bold">Ocean's Feast</span> – Restaurant. <br>
                          Good Vibes & Great Seafood
                        </p>
                      </div>
                    </div>
                    <div class="col-sm-5 text-center text-sm-left">
                      <div class="card-body pb-0 px-0 px-md-4">
                        <img
                          src="../../img/banner.PNG"
                          height="160"
                          alt="View Badge User"
                          data-app-dark-img="illustrations/man-with-laptop-dark.png"
                          data-app-light-img="illustrations/man-with-laptop-light.png" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 order-1">
                <div class="row">
                <div class="col-lg-6 col-md-12 col-6 mb-4">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
          <img
            src="../../dash/assets/img/icons/unicons/customer.png"
            alt="Credit Card"
            class="rounded" />
        </div>
        <div class="dropdown">
          <button
            class="btn p-0"
            type="button"
            id="cardOpt6"
            data-bs-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false">
          </button>
          <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
            <a class="dropdown-item" href="javascript:void(0);">View More</a>
          </div>
        </div>
      </div>
      <span class="fw-semibold d-block mb-1">Table Resv</span>
      <span class="badge bg-label-warning rounded-pill">Pending Approval</span>
      <h3 class="card-title text-nowrap mb-1"><?= $pendingTableResv ?></h3>
    </div>
  </div>
</div>

<div class="col-lg-6 col-md-12 col-6 mb-4">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
          <img
            src="../../dash/assets/img/icons/unicons/customer (1).png"
            alt="Reservation"
            class="rounded" />
        </div>
        <div class="dropdown">
          <button
            class="btn p-0"
            type="button"
            id="cardOpt6"
            data-bs-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false">
          </button>
          <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
            <a class="dropdown-item" href="javascript:void(0);">View More</a>
          </div>
        </div>
      </div>
      <span class="fw-semibold d-block mb-1">Total Table Resv</span>
      <span class="badge bg-label-info rounded-pill">Today</span>
      <h3 class="card-title text-nowrap mb-1"><?= $totalTodayTableResv ?></h3>
    </div>
  </div>
</div>


                </div>
              </div>
              
              <!-- Total Revenue -->
              <!-- Filter + Chart Container -->
<div class="col-12 col-lg-8 order-2 order-md-3 order-lg-2 mb-4">
  <div class="card">
    <div class="row row-bordered g-0">
      <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center px-4 pt-3">
          <h5 class="mb-0">Sales & Table Reservations</h5>
          <select id="filterSelect" class="form-select w-auto">
            <option value="week" selected>This Week</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
          </select>
        </div>
        <div id="salesBookingChart" class="px-2 pt-3"></div>
      </div>
    </div>
  </div>
</div>

<!-- ApexCharts -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script>
const chartData = {
  week: {
    categories: <?= json_encode($weekly['labels']) ?>,
    sales: <?= json_encode($weekly['sales']) ?>,
    booking: <?= json_encode($weekly['booking']) ?>
  },
  month: {
    categories: <?= json_encode($monthly['labels']) ?>,
    sales: <?= json_encode($monthly['sales']) ?>,
    booking: <?= json_encode($monthly['booking']) ?>
  },
  year: {
    categories: <?= json_encode($yearly['labels']) ?>,
    sales: <?= json_encode($yearly['sales']) ?>,
    booking: <?= json_encode($yearly['booking']) ?>
  }
};

let chart;

function renderChart(type) {
  const selected = chartData[type];

  const options = {
    chart: { type: 'bar', height: 350 },
    series: [
      { name: 'Sales', data: selected.sales },
      { name: 'Table Reservations', data: selected.booking }
    ],
    xaxis: { categories: selected.categories },
    colors: ['#8472d5', '#e57eca'],
    title: {
      text: 'Sales & Table Reservations - ' + type.charAt(0).toUpperCase() + type.slice(1),
      align: 'center', style: { fontSize: '16px' }
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        endingShape: 'rounded'
      }
    },
    dataLabels: { enabled: false },
    legend: { position: 'top' }
  };

  if (chart) {
    chart.updateOptions(options);
  } else {
    chart = new ApexCharts(document.querySelector("#salesBookingChart"), options);
    chart.render();
  }
}

window.addEventListener("load", function () {
  renderChart('week');
  document.getElementById('filterSelect').addEventListener('change', function () {
    renderChart(this.value);
  });
});
</script>


              <!--/ Total Revenue -->
              <div class="col-12 col-md-8 col-lg-4 order-3 order-md-2">
                <div class="row">
                  <div class="col-6 mb-4">
                  <div class="card">
                  <div class="card-body">
  <div class="card-title d-flex align-items-start justify-content-between">
    <div class="avatar flex-shrink-0">
      <img
        src="../../dash/assets/img/icons/unicons/binge-eating.png"
        alt="Credit Card"
        class="rounded" />
    </div>
    <div class="dropdown">
      <button
        class="btn p-0"
        type="button"
        id="cardOpt6"
        data-bs-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="false">
      </button>
      <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
        <a class="dropdown-item" href="javascript:void(0);">View More</a>
      </div>
    </div>
  </div>
  <span class="fw-semibold d-block mb-1">Dine-In Order</span>
  <span class="badge bg-label-info rounded-pill">Today</span>
  <h3 class="card-title text-nowrap mb-1"><?= $totalDineinToday ?></h3>
</div>

                    </div>
                  </div>
                  <div class="col-6 mb-4">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
          <img src="../../dash/assets/img/icons/unicons/healthy-food.png" alt="Credit Card" class="rounded" />
        </div>
        <div class="dropdown">
          <button class="btn p-0" type="button" id="cardOpt1" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          </button>
        </div>
      </div>
      <span class="fw-semibold d-block mb-1">Delivery Order</span>
      <span class="badge bg-label-info rounded-pill">Today</span>
      <h3 class="card-title text-nowrap mb-2"><?= $totalDeliveryToday ?></h3>
      <small class="text-success fw-semibold"></small>
    </div>
  </div>
</div>

                  <!-- </div>
    <div class="row"> -->
    <div class="col-6 mb-4">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
          <img src="../../dash/assets/img/icons/unicons/salad.png" alt="Credit Card" class="rounded" />
        </div>
        <div class="dropdown">
          <button class="btn p-0" type="button" id="cardOpt4" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          </button>
        </div>
      </div>
      <span class="fw-semibold d-block mb-1">Stock</span>
      <span class="badge bg-label-warning rounded-pill">Low of stock</span>
      <h3 class="card-title text-nowrap mb-2"><?= $totalLowStock ?></h3>
      <small class="text-danger fw-semibold"></small>
    </div>
  </div>
</div>

<div class="col-6 mb-4">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
          <img src="../../dash/assets/img/icons/unicons/salad2.png" alt="Credit Card" class="rounded" />
        </div>
        <div class="dropdown">
          <button
            class="btn p-0"
            type="button"
            id="cardOpt1"
            data-bs-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false">
          </button>
        </div>
      </div>
      <span class="fw-semibold d-block mb-1">Stock</span>
      <span class="badge bg-label-danger rounded-pill">Out of stock</span>
      <h3 class="card-title text-nowrap mb-2"><?= $totalOutStock ?></h3>
      <small class="text-success fw-semibold"></small>
    </div>
  </div>
</div>

                </div>
              </div>
            </div>
            <div class="row">
              <!-- Order Statistics -->
              <!-- <div class="col-md-6 col-lg-4 col-xl-4 order-0 mb-4">
                  <div class="card h-100">
                    <div class="card-header d-flex align-items-center justify-content-between pb-0">
                      <div class="card-title mb-0">
                        <h5 class="m-0 me-2">Order Statistics</h5>
                        <small class="text-muted">42.82k Total Sales</small>
                      </div>
                      <div class="dropdown">
                        <button
                          class="btn p-0"
                          type="button"
                          id="orederStatistics"
                          data-bs-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          <i class="bx bx-dots-vertical-rounded"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
                          <a class="dropdown-item" href="javascript:void(0);">Select All</a>
                          <a class="dropdown-item" href="javascript:void(0);">Refresh</a>
                          <a class="dropdown-item" href="javascript:void(0);">Share</a>
                        </div>
                      </div>
                    </div>
                    <div class="card-body">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex flex-column align-items-center gap-1">
                          <h2 class="mb-2">8,258</h2>
                          <span>Total Orders</span>
                        </div>
                        <div id="orderStatisticsChart"></div>
                      </div>
                      <ul class="p-0 m-0">
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <span class="avatar-initial rounded bg-label-primary"
                              ><i class="bx bx-mobile-alt"></i
                            ></span>
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <h6 class="mb-0">Electronic</h6>
                              <small class="text-muted">Mobile, Earbuds, TV</small>
                            </div>
                            <div class="user-progress">
                              <small class="fw-semibold">82.5k</small>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <span class="avatar-initial rounded bg-label-success"><i class="bx bx-closet"></i></span>
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <h6 class="mb-0">Fashion</h6>
                              <small class="text-muted">T-shirt, Jeans, Shoes</small>
                            </div>
                            <div class="user-progress">
                              <small class="fw-semibold">23.8k</small>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <span class="avatar-initial rounded bg-label-info"><i class="bx bx-home-alt"></i></span>
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <h6 class="mb-0">Decor</h6>
                              <small class="text-muted">Fine Art, Dining</small>
                            </div>
                            <div class="user-progress">
                              <small class="fw-semibold">849k</small>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex">
                          <div class="avatar flex-shrink-0 me-3">
                            <span class="avatar-initial rounded bg-label-secondary"
                              ><i class="bx bx-football"></i
                            ></span>
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <h6 class="mb-0">Sports</h6>
                              <small class="text-muted">Football, Cricket Kit</small>
                            </div>
                            <div class="user-progress">
                              <small class="fw-semibold">99</small>
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                Order Statistics -->

              <!-- Expense Overview -->
              <!-- <div class="col-md-6 col-lg-4 order-1 mb-4">
                  <div class="card h-100">
                    <div class="card-header">
                      <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item">
                          <button
                            type="button"
                            class="nav-link active"
                            role="tab"
                            data-bs-toggle="tab"
                            data-bs-target="#navs-tabs-line-card-income"
                            aria-controls="navs-tabs-line-card-income"
                            aria-selected="true"
                          >
                            Income
                          </button>
                        </li>
                        <li class="nav-item">
                          <button type="button" class="nav-link" role="tab">Expenses</button>
                        </li>
                        <li class="nav-item">
                          <button type="button" class="nav-link" role="tab">Profit</button>
                        </li>
                      </ul>
                    </div>
                    <div class="card-body px-0">
                      <div class="tab-content p-0">
                        <div class="tab-pane fade show active" id="navs-tabs-line-card-income" role="tabpanel">
                          <div class="d-flex p-4 pt-3">
                            <div class="avatar flex-shrink-0 me-3">
                              <img src="../../dash/assets/img/icons/unicons/wallet.png" alt="User" />
                            </div>
                            <div>
                              <small class="text-muted d-block">Total Balance</small>
                              <div class="d-flex align-items-center">
                                <h6 class="mb-0 me-1">$459.10</h6>
                                <small class="text-success fw-semibold">
                                  <i class="bx bx-chevron-up"></i>
                                  42.9%
                                </small>
                              </div>
                            </div>
                          </div>
                          <div id="incomeChart"></div>
                          <div class="d-flex justify-content-center pt-4 gap-2">
                            <div class="flex-shrink-0">
                              <div id="expensesOfWeek"></div>
                            </div>
                            <div>
                              <p class="mb-n1 mt-1">Expenses This Week</p>
                              <small class="text-muted">$39 less than last week</small>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                Expense Overview -->

              <!-- Transactions -->
              <!-- <div class="col-md-6 col-lg-4 order-2 mb-4">
                  <div class="card h-100">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="card-title m-0 me-2">Transactions</h5>
                      <div class="dropdown">
                        <button
                          class="btn p-0"
                          type="button"
                          id="transactionID"
                          data-bs-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          <i class="bx bx-dots-vertical-rounded"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="transactionID">
                          <a class="dropdown-item" href="javascript:void(0);">Last 28 Days</a>
                          <a class="dropdown-item" href="javascript:void(0);">Last Month</a>
                          <a class="dropdown-item" href="javascript:void(0);">Last Year</a>
                        </div>
                      </div>
                    </div>
                    <div class="card-body">
                      <ul class="p-0 m-0">
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <img src="../../dash/assets/img/icons/unicons/paypal.png" alt="User" class="rounded" />
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">Paypal</small>
                              <h6 class="mb-0">Send money</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">+82.6</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <img src="../../dash/assets/img/icons/unicons/wallet.png" alt="User" class="rounded" />
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">Wallet</small>
                              <h6 class="mb-0">Mac'D</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">+270.69</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <img src="../../dash/assets/img/icons/unicons/chart.png" alt="User" class="rounded" />
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">Transfer</small>
                              <h6 class="mb-0">Refund</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">+637.91</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <img src="../../dash/assets/img/icons/unicons/cc-success.png" alt="User" class="rounded" />
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">Credit Card</small>
                              <h6 class="mb-0">Ordered Food</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">-838.71</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            <img src="../../dash/assets/img/icons/unicons/wallet.png" alt="User" class="rounded" />
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">Wallet</small>
                              <h6 class="mb-0">Starbucks</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">+203.33</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                        <li class="d-flex">
                          <div class="avatar flex-shrink-0 me-3">
                            <img src="../../dash/assets/img/icons/unicons/cc-warning.png" alt="User" class="rounded" />
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">Mastercard</small>
                              <h6 class="mb-0">Ordered Food</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">-92.45</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
               Transactions -->
            </div>
          </div>
          <!-- / Content -->

          <!-- Footer -->
          <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
              <div class="mb-2 mb-md-0">
                ©
                <script>
                  document.write(new Date().getFullYear());
                </script>
                , made with ❤️ by Nivia & Anisa
              </div>
            </div>
          </footer>
          <!-- / Footer -->

          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
  </div>

  <!-- Core JS -->
  <!-- build:js assets/vendor/js/core.js -->
  <script src="../../dash/assets/vendor/libs/jquery/jquery.js"></script>
  <script src="../../dash/assets/vendor/libs/popper/popper.js"></script>
  <script src="../../dash/assets/vendor/js/bootstrap.js"></script>
  <script src="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

  <script src="../../dash/assets/vendor/js/menu.js"></script>
  <!-- endbuild -->

  <!-- Vendors JS -->
  <script src="../../dash/assets/vendor/libs/apex-charts/apexcharts.js"></script>

  <!-- Main JS -->
  <script src="../../dash/assets/js/main.js"></script>

  <!-- Page JS -->
  <script src="../../dash/assets/js/dashboards-analytics.js"></script>

  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>