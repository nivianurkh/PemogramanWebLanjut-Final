<?php
echo password_hash("password123", PASSWORD_DEFAULT);
