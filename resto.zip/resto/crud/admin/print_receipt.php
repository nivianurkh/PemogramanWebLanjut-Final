<?php
$db = include 'koneksi.php';

// Ambil ID order dari query string
$id_order = isset($_GET['id_order']) ? (int)$_GET['id_order'] : 0;
if ($id_order <= 0) {
  die("ID Order tidak ditemukan.");
}

// Ambil data order
$stmt = $db->prepare("SELECT o.*, p.firstname, p.lastname, p.no_hp 
                      FROM orders o 
                      JOIN pelanggan p ON o.id_pelanggan = p.id_pelanggan 
                      WHERE o.id_order = ?");
$stmt->execute([$id_order]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
  die("Data order tidak ditemukan.");
}

// Ambil detail item pesanan
$stmt = $db->prepare("SELECT oi.*, m.menu_name 
                      FROM order_items oi 
                      JOIN menu m ON oi.id_menu = m.id 
                      WHERE oi.id_order = ?");
$stmt->execute([$id_order]);
$orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Format data
$tanggal = date('d M Y H:i', strtotime($order['created_at']));
$nama = htmlspecialchars($order['firstname'] . ' ' . $order['lastname']);
$nohp = htmlspecialchars($order['no_hp']);
$total = number_format($order['total_price'], 0, ',', '.');
?>

<!DOCTYPE html>
<html>
<head>
  <title>Struk Pembayaran</title>
  <style>
    body {
      font-family: monospace;
      width: 300px;
      margin: auto;
    }
    h2 {
      text-align: center;
    }
    .line {
      border-top: 1px dashed #000;
      margin: 8px 0;
    }
    table {
      width: 100%;
    }
    td {
      font-size: 14px;
    }
    .right {
      text-align: right;
    }
    @media print {
      body {
        margin: 0;
      }
    }
  </style>
</head>
<body onload="window.print()">
  <h2>Ocean's Feast</h2>
  <div class="line"></div>
  <p>
    Tanggal: <?= $tanggal ?><br>
    Nama: <?= $nama ?><br>
    No HP: <?= $nohp ?><br>
  </p>
  <div class="line"></div>
  <table>
    <?php foreach ($orderItems as $item): ?>
      <tr>
        <td><?= htmlspecialchars($item['menu_name']) ?> x<?= $item['quantity'] ?></td>
        <td class="right">Rp<?= number_format($item['price'], 0, ',', '.') ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
  <div class="line"></div>
  <p class="right"><strong>Total: Rp<?= $total ?></strong></p>
  <div class="line"></div>
  <p style="text-align:center;">Terima kasih!</p>
</body>
</html>
