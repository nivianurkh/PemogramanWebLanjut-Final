<?php
// Menyertakan koneksi database
$db = require_once('koneksi.php'); 

// Mengecek apakah parameter 'id' ada di URL
if (isset($_GET['id'])) {
    // Ambil ID stock yang akan dihapus
    $id = $_GET['id'];

    // Query untuk menghapus data stock berdasarkan ID
    $sql = "DELETE FROM stock WHERE id = :id";
    
    // Persiapkan statement
    $stmt = $db->prepare($sql);
    
    // Bind parameter
    $stmt->bindParam(':id', $id);
    
    // Eksekusi query
    if ($stmt->execute()) {
        // Jika berhasil, redirect ke halaman stock.php dengan pesan sukses
        header("Location: stock.php?message=success_delete");
        exit();
    } else {
        // Jika gagal, redirect ke halaman stock.php dengan pesan error
        header("Location: stock.php?message=error_delete");
        exit();
    }
} else {
    // Jika ID tidak ada di URL, redirect ke halaman stock.php
    header("Location: stock.php");
    exit();
}
?>
