<?php
// Include koneksi database
$db = include 'koneksi.php';

// Cek apakah parameter 'id' ada di URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $user_id = $_GET['id'];

    // Ambil data user berdasarkan id
    $stmt = $db->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Cek apakah user ditemukan
    if (!$user) {
        echo "User tidak ditemukan!";
        exit;
    }

    // Proses ketika form disubmit
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Ambil data dari form
        $full_name = $_POST['firstName'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phoneNumber'];
        $role = $_POST['role'];
        $status = $_POST['status'];
        $password = $_POST['password'];

        $check = $db->prepare("SELECT COUNT(*) FROM users WHERE (username = :username OR email = :email) AND id != :id");
$check->bindParam(':username', $username);
$check->bindParam(':email', $email);
$check->bindParam(':id', $user_id, PDO::PARAM_INT);
$check->execute();

$existing = $check->fetchColumn();

if ($existing > 0) {
    header("Location: edit_user.php?id=$user_id&message=duplicate");
    exit;
}


        // Jika password diubah, enkripsi password baru
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $update_sql = "UPDATE users SET full_name = :full_name, username = :username, email = :email, 
                           phone_number = :phone_number, role = :role, status = :status, password = :password
                           WHERE id = :id";
            $stmt = $db->prepare($update_sql);
            $stmt->bindParam(':password', $hashed_password);
        } else {
            // Jika password tidak diubah, cukup update data selain password
            $update_sql = "UPDATE users SET full_name = :full_name, username = :username, email = :email, 
                           phone_number = :phone_number, role = :role, status = :status WHERE id = :id";
            $stmt = $db->prepare($update_sql);
        }

        // Bind parameter
        $stmt->bindParam(':full_name', $full_name);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':phone_number', $phone);
        $stmt->bindParam(':role', $role);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);

        // Eksekusi query
        if ($stmt->execute()) {
            // Jika berhasil, redirect ke halaman user.php dengan pesan success
            // Setelah update berhasil
header("Location: user.php?message=success_update");
exit();

        } else {
            echo "Gagal memperbarui data. Coba lagi.";
        }
    }
} else {
    echo "ID tidak valid!";
    exit;
}
?>

<?php if (isset($_GET['message']) && $_GET['message'] === 'duplicate') : ?>
  <div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div class="toast align-items-center text-bg-danger border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body">
          ❌ Username atau email sudah digunakan.
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  </div>
<?php endif; ?>

<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../../dash/assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Krusty Krab</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../../img/hero.PNG" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../../dash/assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../../dash/assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../../dash/assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../../dash/assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="../../dash/assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../../dash/assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../../dash/assets/js/config.js"></script>

    <style>
    .toast-container {
      z-index: 10560 !important;
      /* lebih tinggi dari modal Bootstrap (1050) */
    }

    .layout-wrapper,
    .container-xxl,
    .card,
    .content-wrapper {
      overflow: visible !important;
    }
  </style>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="index.php" class="app-brand-link">
              <span class="app-brand-logo demo">
                <img src="../../img/hero.PNG" alt="" style="width: 60px;" >
              </span>
              <span class="app-brand-text demo menu-text fw-bolder ms-2">Ocean's Feast</span>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item">
              <a href="index.php" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>

            <!-- Layouts -->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div data-i18n="Layouts">Report</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                    <a href="sales.html" class="menu-link">
                      <div data-i18n="Without menu">Sales</div>
                    </a>
                  </li>
                <li class="menu-item">
                  <a href="monthlyrev.html" class="menu-link">
                    <div data-i18n="Without menu">Monthly Revenue</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="totalrev.html" class="menu-link">
                    <div data-i18n="Without navbar">Total Revenue</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="expenses.html" class="menu-link">
                    <div data-i18n="Container">Expenses</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="totalexpenses.html" class="menu-link">
                    <div data-i18n="Fluid">Total Expenses</div>
                  </a>
                </li>
              </ul>
            </li>

            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Krusty Creations & Secrets</span>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                <div data-i18n="Account Settings">Master Data </div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="krustyspecial.html" class="menu-link">
                    <div data-i18n="Account">Menu</div>
                  </a>
                </li>
                <!-- <li class="menu-item">
                  <a href="lunchcombos.html" class="menu-link">
                    <div data-i18n="Notifications">Category Menu</div>
                  </a>
                </li> -->
                <!-- <li class="menu-item">
                  <a href="snackssips.html" class="menu-link">
                    <div data-i18n="Connections">Snacks & Sips</div>
                  </a>
                </li> -->
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-box"></i>
                <div data-i18n="Authentications">Stock Management</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="stock.php" class="menu-link">
                    <div data-i18n="Basic">Stock</div>
                  </a>
                </li>
                <!-- <li class="menu-item">
                  <a href="report_stock" class="menu-link" target="_blank">
                    <div data-i18n="Basic">Report Stock</div>
                  </a>
                </li> -->
              </ul>
            </li>
            
            <!-- Auth -->
            <li class="menu-header small text-uppercase"><span class="menu-header-text">User Management</span></li>
            <!-- Cards -->
            <li class="menu-item active">
              <a href="user.php" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">User</div>
              </a>
            </li>
            <!-- <li class="menu-item">
                <a href="changepass.html" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-lock-open-alt"></i>
                  <div data-i18n="Basic">Change Password</div>
                </a>
              </li> -->
        </aside>
        <!-- / Menu -->


        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- User -->
                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                      <img src="../../img/team-1.JPG" alt class="w-px-40 h-auto rounded-circle" />
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                      <a class="dropdown-item" href="#">
                        <div class="d-flex">
                          <div class="flex-shrink-0 me-3">
                            <div class="avatar avatar-online">
                              <img src="../../img/team-1.JPG" alt class="w-px-40 h-auto rounded-circle" />
                            </div>
                          </div>
                          <div class="flex-grow-1">
                            <span class="fw-semibold d-block">Mr. Crab</span>
                            <small class="text-muted">Owner</small>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-user me-2"></i>
                        <span class="align-middle">My Profile</span>
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-cog me-2"></i>
                        <span class="align-middle">Settings</span>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="auth-login-basic.html">
                        <i class="bx bx-power-off me-2"></i>
                        <span class="align-middle">Log Out</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <!--/ User -->
              </ul>
            </div>
          </nav>
          <!-- / Navbar -->

          <div class="content-wrapper">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">User Management /</span>Edit User</h4>
  
                <div class="row">
                  <div class="col-md-12">
                    <div class="card mb-4">
                      <h5 class="card-header">Edit User</h5>
                      <!-- Account -->
                      <div class="card-body">
                        
                      <hr class="my-0" />
                      <div class="card-body">
                      <form id="formAccountSettings" method="POST">
    <div class="row">
        <div class="mb-3 col-md-6">
            <label for="firstName" class="form-label">
                Full Name <span style="color: red;">*</span>
            </label>
            <input
                class="form-control"
                type="text"
                id="firstName"
                name="firstName"
                value="<?php echo htmlspecialchars($user['full_name']); ?>"
                autofocus
                required
            />
        </div>

        <div class="mb-3 col-md-6">
    <label for="username" class="form-label">
        Username <span style="color: red;">*</span>
    </label>
    <input
        class="form-control"
        type="text"
        id="username"
        name="username"
        value="<?php echo htmlspecialchars($user['username']); ?>"
        required
        pattern="[A-Za-z0-9]+"
        title="Username can only contain letters and numbers (no spaces or symbols)."
    />
</div>


        <div class="mb-3 col-md-6">
            <label for="email" class="form-label">
                Email <span style="color: red;">*</span>
            </label>
            <input
                class="form-control"
                type="email"
                id="email"
                name="email"
                value="<?php echo htmlspecialchars($user['email']); ?>"
                required
            />
        </div>

        <div class="mb-3 col-md-6">
  <label for="phoneNumber" class="form-label">
    Phone Number <span style="color: red;">*</span>
  </label>
  <div class="input-group">
    <span class="input-group-text">+62</span>
    <input
      class="form-control"
      type="text"
      id="phoneNumber"
      name="phoneNumber"
      value="<?php echo htmlspecialchars($user['phone_number']); ?>"
      required
      oninput="onlyNumbers(event)"
      pattern="^\d{8,13}$"
      title="The phone number must be between 8 and 13 digits."
    />
  </div>
</div>

<script>
  function onlyNumbers(event) {
    const input = event.target;
    let value = input.value.replace(/[^0-9]/g, '');
    // Hapus nol di awal jika ada
    if (value.startsWith('0')) {
      value = value.substring(1);
    }
    input.value = value;
  }
</script>



        <div class="mb-3 col-md-6">
            <label class="form-label" for="role">
                Role <span style="color: red;">*</span>
            </label>
            <select id="role" name="role" class="select2 form-select" required>
                <option value="Super Admin" <?php echo ($user['role'] == 'Super Admin') ? 'selected' : ''; ?>>Super Admin</option>
                <option value="Cashier" <?php echo ($user['role'] == 'Cashier') ? 'selected' : ''; ?>>Cashier</option>
            </select>
        </div>

        <div class="mb-3 col-md-6 form-password-toggle">
  <label class="form-label" for="password">Password</label>
  <div class="input-group input-group-merge">
    <input 
      type="password" 
      id="password" 
      class="form-control" 
      name="password"
      minlength="8"
      title="Password must be at least 8 characters with uppercase, lowercase, numbers, and special characters."
    />
    <button type="button" class="btn btn-outline-secondary" onclick="generatePassword()" title="Generate Password">
      <i class="bx bx-refresh"></i>
    </button>
    <span class="input-group-text cursor-pointer" onclick="togglePasswordVisibility()">
      <i id="togglePasswordIcon" class="bx bx-hide"></i>
    </span>
  </div>
</div>

<script>
  function generatePassword(length = 12) {
    const lowercase = "abcdefghijklmnopqrstuvwxyz";
    const uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const digits = "0123456789";
    const special = "!@#$%^&*?";
    const all = lowercase + uppercase + digits + special;

    let password = [
      lowercase[Math.floor(Math.random() * lowercase.length)],
      uppercase[Math.floor(Math.random() * uppercase.length)],
      digits[Math.floor(Math.random() * digits.length)],
      special[Math.floor(Math.random() * special.length)]
    ];

    for (let i = password.length; i < length; i++) {
      password.push(all[Math.floor(Math.random() * all.length)]);
    }

    password = password.sort(() => Math.random() - 0.5).join('');
    const passwordField = document.getElementById("password");
    passwordField.value = password;
    validatePassword();
  }

  function togglePasswordVisibility() {
    const passwordField = document.getElementById("password");
    const icon = document.getElementById("togglePasswordIcon");
    if (passwordField.type === "password") {
      passwordField.type = "text";
      icon.classList.replace("bx-hide", "bx-show");
    } else {
      passwordField.type = "password";
      icon.classList.replace("bx-show", "bx-hide");
    }
  }

  function validatePassword() {
    const passwordInput = document.getElementById('password');
    const password = passwordInput.value;
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@\$%\^&\*\?])[A-Za-z\d!@\$%\^&\*\?]{8,}$/;

    if (password && !regex.test(password)) {
      passwordInput.setCustomValidity("Password must be at least 8 characters with uppercase, lowercase, numbers, and special characters.");
    } else {
      passwordInput.setCustomValidity("");
    }
  }

  document.getElementById('password').addEventListener('input', validatePassword);

  document.getElementById('formAccountSettings').addEventListener('submit', function(event) {
    const passwordInput = document.getElementById('password');
    if (passwordInput.value && !passwordInput.validity.valid) {
      event.preventDefault();
      alert("Invalid password. Please ensure your password meets the required criteria.");
    }
  });
</script>

        <div class="mb-3 col-md-6">
            <label class="form-label" for="status">
                Status <span style="color: red;">*</span>
            </label>
            <select id="status" name="status" class="select2 form-select" required>
                <option value="Active" <?php echo ($user['status'] == 'Active') ? 'selected' : ''; ?>>Active</option>
                <option value="Inactive" <?php echo ($user['status'] == 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
            </select>
        </div>

        <div class="mb-3 col-md-12" style="text-align: right;">
        <button
                              type="button"
                              class="btn"
                              style="width: 100px; border-color: #b884de;"
                              onclick="window.location.href='user.php'">
                              Cancel
                            </button>
            <button type="submit" class="btn btn-primary" style="width: 100px; margin-left: 10px;">Save</button>
        </div>
    </div>
</form>

                        
                      </div>
                      <!-- /Account -->
                    </div>
                  </div>
                </div>
              </div>
            <!-- / Content -->


              <!-- Bootstrap Dark Table -->
              <!-- <div class="card">
                <h5 class="card-header">Monthly Sales Report</h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Rank</th>
                        <th>Menu</th>
                        <th>Qty</th>
                        <th>Profit</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <tr>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>01</strong></td>
                        <td>Double Patty</td>
                        <td>120</td>
                        <td><span class="badge bg-label-success me-1">2760$</span></td>
                      </tr>
                      <tr>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>02</strong></td>
                        <td>Krabby Patty</td>
                        <td>94</td>
                        <td><span class="badge bg-label-success me-1">1128$</span></td>
                      </tr>
                      <tr>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>03</strong></td>
                        <td>Krabby Patty Special</td>
                        <td>80</td>
                        <td><span class="badge bg-label-success me-1">1440$</span></td>
                      </tr>
                      <tr>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>04</strong></td>
                        <td>Lemon Tea</td>
                        <td>76</td>
                        <td><span class="badge bg-label-success me-1">608$</span></td>
                      </tr>
                      <tr>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>04</strong></td>
                        <td>Nuggets</td>
                        <td>53</td>
                        <td><span class="badge bg-label-success me-1">530$</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div> -->
              <!--/ Bootstrap Dark Table -->
            <!-- / Content -->

 <!-- Footer -->
 <footer class="content-footer footer bg-footer-theme">
  <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
    <div class="mb-2 mb-md-0">
      ©
      <script>
        document.write(new Date().getFullYear());
      </script>
      , made with ❤️ by Nivia & Anisa
    </div>
  </div>
</footer>
<!-- / Footer -->

<div class="content-backdrop fade"></div>
</div>
<!-- Content wrapper -->
</div>
<!-- / Layout page -->
</div>

<!-- Overlay -->
<div class="layout-overlay layout-menu-toggle"></div>
</div>

<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="../../dash/assets/vendor/libs/jquery/jquery.js"></script>
<script src="../../dash/assets/vendor/libs/popper/popper.js"></script>
<script src="../../dash/assets/vendor/js/bootstrap.js"></script>
<script src="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

<script src="../../dash/assets/vendor/js/menu.js"></script>
<!-- endbuild -->

<!-- Vendors JS -->
<script src="../../dash/assets/vendor/libs/apex-charts/apexcharts.js"></script>

<!-- Main JS -->
<script src="../../dash/assets/js/main.js"></script>

<!-- Page JS -->
<script src="../../dash/assets/js/dashboards-analytics.js"></script>

<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
      const toastEl = document.querySelector('.toast');
      if (toastEl) {
        const toast = new bootstrap.Toast(toastEl, {
          delay: 3000,
          autohide: true
        });
        toast.show();
      }
    });
  </script>
</body>

</html>
