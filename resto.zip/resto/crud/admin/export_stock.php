<?php
// Ambil koneksi database
$db = include 'koneksi.php';

// Query semua data stock (tanpa pagination)
$sql = "SELECT * FROM stock ORDER BY expired_date ASC";
$stmt = $db->prepare($sql);
$stmt->execute();
$stocks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set header agar browser mengenali ini sebagai file Excel dan langsung mengunduh
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=stock_data.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Output data sebagai tabel HTML (dibaca oleh Excel)
echo "<table border='1'>";
echo "<tr>
        <th>Kode Bahan</th>
        <th>Nama Bahan</th>
        <th>Jumlah</th>
        <th>Satuan</th>
        <th>Status</th>
        <th>Expired Date</th>
      </tr>";

// Loop untuk menampilkan isi tabel
foreach ($stocks as $row) {
    echo "<tr>
            <td>{$row['ingredient_code']}</td>
            <td>{$row['ingredient_name']}</td>
            <td>{$row['quantity']}</td>
            <td>{$row['unit']}</td>
            <td>{$row['status']}</td>
            <td>{$row['expired_date']}</td>
          </tr>";
}

echo "</table>";
exit;
