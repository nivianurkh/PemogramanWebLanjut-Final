<?php
// Ambil koneksi database
date_default_timezone_set('Asia/Jakarta');
$db = include 'koneksi.php';

// Ambil parameter dari GET
$rawSearch  = isset($_GET['search']) ? $_GET['search'] : '';
$search     = "%" . $rawSearch . "%";
$startDate  = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate    = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Query data sesuai filter
$sql = "SELECT o.created_at, o.midtrans_order_id, o.total_price,
               p.firstname, p.lastname, p.no_hp
        FROM orders o
        JOIN pelanggan p ON o.id_pelanggan = p.id_pelanggan
        WHERE o.order_type = 'dine-in'
        AND (
            CONCAT_WS(' ', p.firstname, p.lastname) LIKE :search
            OR p.no_hp LIKE :search
            OR o.midtrans_order_id LIKE :search
        )";

if (!empty($startDate) && !empty($endDate)) {
    $sql .= " AND DATE(o.created_at) BETWEEN :startDate AND :endDate";
}

$sql .= " ORDER BY o.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->bindValue(':search', $search, PDO::PARAM_STR);
if (!empty($startDate) && !empty($endDate)) {
    $stmt->bindValue(':startDate', $startDate, PDO::PARAM_STR);
    $stmt->bindValue(':endDate', $endDate, PDO::PARAM_STR);
}
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set header agar browser mengenali ini sebagai file Excel
$exportDate = date('Y-m-d_H-i');
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=report_dinein_sales_{$exportDate}.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Output data sebagai tabel HTML (dibaca oleh Excel)
echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Order Date & Time</th>
        <th>Midtrans Order ID</th>
        <th>Customer Name</th>
        <th>Phone Number</th>
        <th>Total Order</th>
      </tr>";

 $no = 1;
foreach ($orders as $row) {
    $tanggal = htmlspecialchars($row['created_at']);
    $orderID = htmlspecialchars($row['midtrans_order_id']);
    $nama    = htmlspecialchars($row['firstname'] . ' ' . $row['lastname']);
    $noHP    = htmlspecialchars($row['no_hp']);
    $total   = number_format($row['total_price'], 0, ',', '.');

    echo "<tr>
            <td>{$no}</td>
            <td>{$tanggal}</td>
            <td>{$orderID}</td>
            <td>{$nama}</td>
            <td>{$noHP}</td>
            <td>Rp {$total}</td>
          </tr>";
          $no++;
}

echo "</table>";
exit;
