<?php
// koneksi
$db = include 'koneksi.php';

// Ambil ID dari parameter URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil detail reservasi
$stmt = $db->prepare("SELECT * FROM table_reservations WHERE id = :id");
$stmt->execute([':id' => $id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    echo "<div class='alert alert-danger m-4'>Reservation not found.</div>";
    exit;
}
?>

<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../../dash/assets/"
    data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Ocean's Feast</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../../img/hero.PNG" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet" />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../../dash/assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../../dash/assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../../dash/assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../../dash/assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="../../dash/assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../../dash/assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../../dash/assets/js/config.js"></script>

    <style>
        .toast-container {
            z-index: 10560 !important;
            /* lebih tinggi dari modal Bootstrap (1050) */
        }

        .layout-wrapper,
        .container-xxl,
        .card,
        .content-wrapper {
            overflow: visible !important;
        }
    </style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div class="app-brand demo">
                    <a href="index.php" class="app-brand-link">
                        <span class="app-brand-logo demo">
                            <img src="../../img/hero.PNG" alt="" style="width: 60px;">
                        </span>
                        <span class="app-brand-text demo menu-text fw-bolder ms-2">Ocean's Feast</span>
                    </a>

                    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                        <i class="bx bx-chevron-left bx-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>

                <ul class="menu-inner py-1">
                    <!-- Dashboard -->
                    <li class="menu-item">
                        <a href="index.php" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-home-circle"></i>
                            <div data-i18n="Analytics">Dashboard</div>
                        </a>
                    </li>

                    <!-- Layouts -->
                    <li class="menu-item">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-layout"></i>
                            <div data-i18n="Layouts">Report</div>
                        </a>

                        <ul class="menu-sub">
                            <li class="menu-item">
                                <a href="sales.html" class="menu-link">
                                    <div data-i18n="Without menu">Sales</div>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a href="monthlyrev.html" class="menu-link">
                                    <div data-i18n="Without menu">Monthly Revenue</div>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a href="totalrev.html" class="menu-link">
                                    <div data-i18n="Without navbar">Total Revenue</div>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a href="expenses.html" class="menu-link">
                                    <div data-i18n="Container">Expenses</div>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a href="totalexpenses.html" class="menu-link">
                                    <div data-i18n="Fluid">Total Expenses</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="menu-header small text-uppercase">
                        <span class="menu-header-text">Krusty Creations & Secrets</span>
                    </li>
                    <li class="menu-item">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-dock-top"></i>
                            <div data-i18n="Account Settings">Master Data</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item">
                                <a href="menu.php" class="menu-link">
                                    <div data-i18n="Account">Menu</div>
                                </a>
                            </li>
                            <!-- <li class="menu-item">
                  <a href="lunchcombos.html" class="menu-link">
                    <div data-i18n="Notifications">Category Menu</div>
                  </a>
                </li> -->
                            <!-- <li class="menu-item">
                  <a href="snackssips.html" class="menu-link">
                    <div data-i18n="Connections">Snacks & Sips</div>
                  </a>
                </li> -->
                        </ul>
                    </li>
                    <li class="menu-item">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-box"></i>
                            <div data-i18n="Authentications">Stock Management</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item">
                                <a href="stock.php" class="menu-link" target="_blank">
                                    <div data-i18n="Basic">Stock</div>
                                </a>
                            </li>
                            <!-- <li class="menu-item">
                  <a href="report_stock" class="menu-link" target="_blank">
                    <div data-i18n="Basic">Report Stock</div>
                  </a>
                </li> -->
                        </ul>
                    </li>
                    <li class="menu-item">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-box"></i>
                            <div data-i18n="Authentications">Transaction</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item active">
                                <a href="table_reservations.php" class="menu-link" target="_blank">
                                    <div data-i18n="Basic">Table Reservation</div>
                                </a>
                            </li>
                            <!-- <li class="menu-item">
                  <a href="report_stock" class="menu-link" target="_blank">
                    <div data-i18n="Basic">Report Stock</div>
                  </a>
                </li> -->
                        </ul>
                    </li>

                    <!-- Auth -->
                    <li class="menu-header small text-uppercase"><span class="menu-header-text">User Management</span></li>
                    <!-- Cards -->
                    <li class="menu-item">
                        <a href="user.php" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-collection"></i>
                            <div data-i18n="Basic">User</div>
                        </a>
                    </li>
            </aside>
            <!-- / Menu -->


            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                <nav
                    class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                    id="layout-navbar">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="../../img/team-1.JPG" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="../../img/team-1.JPG" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-semibold d-block">Mr. Crab</span>
                                                    <small class="text-muted">Owner</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <i class="bx bx-user me-2"></i>
                                            <span class="align-middle">My Profile</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <i class="bx bx-cog me-2"></i>
                                            <span class="align-middle">Settings</span>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="auth-login-basic.html">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <!-- / Navbar -->

                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Tabel Reservations /</span>View</h4>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card mb-4">
                                    <h5 class="card-header">View</h5>
                                    <!-- Account -->
                                    <div class="card-body">
                                        <hr class="my-0" />
                                        <div class="card-body">
                                        <form id="formReservationDetails" class="mb-4">
  <div class="row">
    <div class="mb-3 col-md-6">
      <label class="form-label">Full Name</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['name']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Email</label>
      <input class="form-control" type="email" value="<?= htmlspecialchars($reservation['email']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Phone</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['phone']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Reservation Datetime</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['reservation_datetime']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Number of People</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['number_of_people']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Status</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['status']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Payment Status</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['payment_status']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Transaction ID</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['transaction_id']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-6">
  <label class="form-label">Price</label>
  <input class="form-control" type="text" value="<?= 'Rp ' . number_format($reservation['price'], 0, ',', '.') ?>" readonly />
</div>

    <div class="mb-3 col-md-6">
      <label class="form-label">Created At</label>
      <input class="form-control" type="text" value="<?= htmlspecialchars($reservation['created_at']) ?>" readonly />
    </div>

    <div class="mb-3 col-md-12">
  <label class="form-label">Rejection Reason</label>
  <textarea class="form-control" rows="3" readonly><?= htmlspecialchars($reservation['rejection_reason']) ?></textarea>
</div>

    <div class="mb-3 col-md-12">
      <label class="form-label">Special Request</label>
      <textarea class="form-control" rows="3" readonly><?= htmlspecialchars($reservation['special_request']) ?></textarea>
    </div>

    <div class="mb-3 col-md-12">
  <label class="form-label">QR Code</label><br>
  <?php if (
    isset($reservation['payment_status']) &&
    strtolower($reservation['payment_status']) === 'paid' &&
    !empty($reservation['qr_code'])
  ): ?>
    <img src="<?= htmlspecialchars($reservation['qr_code']) ?>" alt="QR Code" style="max-width: 150px;">
  <?php else: ?>
    <p>-</p>
  <?php endif; ?>
</div>




    <div class="mb-3 d-flex justify-content-end gap-2">
  <!-- <a href="#" class="btn btn-primary" onclick="confirmApprove(event)">Approve</a>
  <a href="#" class="btn btn-secondary" onclick="confirmReject(event)">Reject</a> -->
  <a href="table_reservations.php" class="btn btn-secondary">Back</a>
</div>

<script>
  function confirmApprove(event) {
    event.preventDefault(); // Mencegah link langsung berjalan
    Swal.fire({
      title: 'Are you sure?',
      text: "You are about to approve this reservation.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#b884dd', // Bootstrap success green
      cancelButtonColor: '#6c757d',  // Bootstrap secondary
      confirmButtonText: 'Yes, approve it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Ganti dengan redirect atau aksi submit form
        window.location.href = "approve_reservation.php"; // ubah sesuai kebutuhan
      }
    });
  }

  function confirmReject(event) {
    event.preventDefault();
    Swal.fire({
      title: 'Are you sure?',
      text: "You are about to reject this reservation.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#b884dd', // Bootstrap danger red
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, reject it!'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = "reject_reservation.php"; // ubah sesuai kebutuhan
      }
    });
  }
</script>


  </div>
</form>


                                        </div>
                                    </div>
                                    <!-- /Account -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- / Content -->

                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                            <div class="mb-2 mb-md-0">
                                ©
                                <script>
                                    document.write(new Date().getFullYear());
                                </script>
                                , made with ❤️ by Nivia & Anisa
                            </div>
                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="../../dash/assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../../dash/assets/vendor/libs/popper/popper.js"></script>
    <script src="../../dash/assets/vendor/js/bootstrap.js"></script>
    <script src="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../../dash/assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../../dash/assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../../dash/assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../../dash/assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>

    <?php if (isset($_GET['message']) && $_GET['message'] === 'success') : ?>
        <div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 10560;">
            <div class="toast align-items-center text-bg-success border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        ✅ User berhasil ditambahkan!
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toastEl = document.querySelector('.toast');
            if (toastEl) {
                const toast = new bootstrap.Toast(toastEl, {
                    delay: 3000,
                    autohide: true
                });
                toast.show();
            }
        });
    </script>
</body>

</html>