<?php
session_start();
require_once '../koneksi.php'; // pastikan path ke koneksi.php benar

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $orderId = $_POST['order_id'] ?? '';
  $status = $_POST['status'] ?? '';

  if (!empty($orderId) && !empty($status)) {
    $stmt = $db->prepare("UPDATE delivery_orders SET status = :status WHERE id = :id");
    $stmt->execute([
      ':status' => $status,
      ':id' => $orderId
    ]);
  }
}

header('Location: cashier_delivery.php');
exit;
          