<?php
// Ambil koneksi database
date_default_timezone_set('Asia/Jakarta');
$db = include 'koneksi.php';

// Ambil parameter dari GET
$rawSearch  = isset($_GET['search']) ? $_GET['search'] : '';
$search     = "%" . $rawSearch . "%";

// Query data pelanggan
$sql = "SELECT firstname, lastname, email, no_hp, username
        FROM pelanggan
        WHERE (
            CONCAT_WS(' ', firstname, lastname) LIKE :search
            OR email LIKE :search
            OR no_hp LIKE :search
            OR username LIKE :search
        )
        ORDER BY firstname ASC";

$stmt = $db->prepare($sql);
$stmt->bindValue(':search', $search, PDO::PARAM_STR);
$stmt->execute();
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set header agar browser mengenali ini sebagai file Excel
$exportDate = date('Y-m-d_H-i');
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=report_customers_{$exportDate}.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Output data sebagai tabel HTML (dibaca oleh Excel)
echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Full Name</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>Username</th>
      </tr>";

$no = 1;
foreach ($customers as $row) {
    $fullName = htmlspecialchars($row['firstname'] . ' ' . $row['lastname']);
    $email    = htmlspecialchars($row['email']);
    $phone    = htmlspecialchars($row['no_hp']);
    $username = htmlspecialchars($row['username']);

    echo "<tr>
            <td>{$no}</td>
            <td>{$fullName}</td>
            <td>{$email}</td>
            <td>{$phone}</td>
            <td>{$username}</td>
          </tr>";
    $no++;
}

echo "</table>";
exit;
