<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = require_once 'koneksi.php';

// PHPMailer
require_once 'PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer-master/src/SMTP.php';
require_once 'PHPMailer-master/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $rejection_reason = $_POST['rejection_reason'] ?? '';

    if ($id && !empty($rejection_reason)) {
        try {
            // Ambil data reservasi
            $stmt = $conn->prepare("SELECT name, email FROM table_reservations WHERE id = ?");
            $stmt->execute([$id]);
            $reservation = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$reservation) {
                die("Reservation not found.");
            }

            $name = $reservation['name'];
            $email = $reservation['email'];

            // Update status dan simpan alasan penolakan
            $stmt = $conn->prepare("UPDATE table_reservations SET status = 'rejected', rejection_reason = ? WHERE id = ?");
            $stmt->execute([$rejection_reason, $id]);

            // Kirim email
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'anisa.indriani@widyatama.ac.id'; // GANTI
            $mail->Password   = 'smczlewnlvhjibid';               // GANTI
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            $mail->setFrom('anisa.indriani@widyatama.ac.id', 'Resto Management'); // GANTI
            $mail->addAddress($email, $name);

            $mail->isHTML(true);
            $mail->Subject = 'Reservation Rejected';
            $mail->Body    = "
                <html>
                <body>
                    <p>Dear <strong>$name</strong>,</p>
                    <p>We regret to inform you that your reservation has been <strong>rejected</strong>.</p>
                    <p><strong>Reason:</strong> " . htmlspecialchars($rejection_reason) . "</p>
                    <p>Thank you for your understanding.<br>Resto Management</p>
                </body>
                </html>
            ";

            $mail->send();

            header("Location: table_reservations.php?message=rejected");
            exit;
        } catch (Exception $e) {
            echo "Email error: " . $e->getMessage();
        } catch (PDOException $e) {
            echo "Database error: " . $e->getMessage();
        }
    } else {
        header("Location: table_reservations.php?message=invalid");
        exit;
    }
} else {
    header("Location: table_reservations.php?message=invalid");
    exit;
}
