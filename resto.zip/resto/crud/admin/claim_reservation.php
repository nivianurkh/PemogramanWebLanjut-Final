<?php
$db = include 'koneksi.php';

$id = $_GET['id'] ?? '';
if (!$id) {
  echo 'error';
  exit;
}

$stmt = $db->prepare("UPDATE table_reservations SET status = 'claimed' WHERE id = ?");
$success = $stmt->execute([$id]);

echo $success ? 'ok' : 'error';
